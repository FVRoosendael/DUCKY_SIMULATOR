﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Ducky_sim
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.But_Simulate = New System.Windows.Forms.Button()
        Me.But_End = New System.Windows.Forms.Button()
        Me.TxtB_source = New System.Windows.Forms.TextBox()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.LoadToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.StartSimulationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CompileCodeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.Lbl_Current_Filename = New System.Windows.Forms.Label()
        Me.FolderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'But_Simulate
        '
        Me.But_Simulate.Location = New System.Drawing.Point(183, 386)
        Me.But_Simulate.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.But_Simulate.Name = "But_Simulate"
        Me.But_Simulate.Size = New System.Drawing.Size(684, 54)
        Me.But_Simulate.TabIndex = 0
        Me.But_Simulate.Text = "Start &Simulation"
        Me.But_Simulate.UseVisualStyleBackColor = True
        '
        'But_End
        '
        Me.But_End.AutoSize = True
        Me.But_End.Location = New System.Drawing.Point(183, 449)
        Me.But_End.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.But_End.Name = "But_End"
        Me.But_End.Size = New System.Drawing.Size(684, 54)
        Me.But_End.TabIndex = 1
        Me.But_End.Text = "E&xit"
        Me.But_End.UseVisualStyleBackColor = True
        '
        'TxtB_source
        '
        Me.TxtB_source.Location = New System.Drawing.Point(11, 63)
        Me.TxtB_source.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TxtB_source.Multiline = True
        Me.TxtB_source.Name = "TxtB_source"
        Me.TxtB_source.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.TxtB_source.Size = New System.Drawing.Size(856, 318)
        Me.TxtB_source.TabIndex = 2
        Me.TxtB_source.WordWrap = False
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1, Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Padding = New System.Windows.Forms.Padding(5, 2, 0, 2)
        Me.MenuStrip1.Size = New System.Drawing.Size(881, 30)
        Me.MenuStrip1.TabIndex = 5
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LoadToolStripMenuItem, Me.SaveToolStripMenuItem, Me.ToolStripSeparator3, Me.StartSimulationToolStripMenuItem, Me.CompileCodeToolStripMenuItem, Me.ToolStripSeparator1, Me.ExitToolStripMenuItem})
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(54, 26)
        Me.ToolStripMenuItem1.Text = "Start"
        '
        'LoadToolStripMenuItem
        '
        Me.LoadToolStripMenuItem.Name = "LoadToolStripMenuItem"
        Me.LoadToolStripMenuItem.Size = New System.Drawing.Size(198, 26)
        Me.LoadToolStripMenuItem.Text = "Load"
        '
        'SaveToolStripMenuItem
        '
        Me.SaveToolStripMenuItem.Name = "SaveToolStripMenuItem"
        Me.SaveToolStripMenuItem.Size = New System.Drawing.Size(198, 26)
        Me.SaveToolStripMenuItem.Text = "Save"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(195, 6)
        '
        'StartSimulationToolStripMenuItem
        '
        Me.StartSimulationToolStripMenuItem.Name = "StartSimulationToolStripMenuItem"
        Me.StartSimulationToolStripMenuItem.Size = New System.Drawing.Size(198, 26)
        Me.StartSimulationToolStripMenuItem.Text = "Start Simulation"
        '
        'CompileCodeToolStripMenuItem
        '
        Me.CompileCodeToolStripMenuItem.Name = "CompileCodeToolStripMenuItem"
        Me.CompileCodeToolStripMenuItem.Size = New System.Drawing.Size(198, 26)
        Me.CompileCodeToolStripMenuItem.Text = "Compile Code"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(195, 6)
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(198, 26)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ContentToolStripMenuItem, Me.ToolStripSeparator2, Me.AboutToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(55, 26)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'ContentToolStripMenuItem
        '
        Me.ContentToolStripMenuItem.Name = "ContentToolStripMenuItem"
        Me.ContentToolStripMenuItem.Size = New System.Drawing.Size(145, 26)
        Me.ContentToolStripMenuItem.Text = "Support"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(142, 6)
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(145, 26)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImage = Global.Ducky_sim.My.Resources.Resources.ducky
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.InitialImage = Global.Ducky_sim.My.Resources.Resources.ducky
        Me.PictureBox1.Location = New System.Drawing.Point(11, 386)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(167, 117)
        Me.PictureBox1.TabIndex = 6
        Me.PictureBox1.TabStop = False
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'Lbl_Current_Filename
        '
        Me.Lbl_Current_Filename.AutoSize = True
        Me.Lbl_Current_Filename.Location = New System.Drawing.Point(13, 35)
        Me.Lbl_Current_Filename.Name = "Lbl_Current_Filename"
        Me.Lbl_Current_Filename.Size = New System.Drawing.Size(117, 16)
        Me.Lbl_Current_Filename.TabIndex = 7
        Me.Lbl_Current_Filename.Text = "Current FileName: "
        '
        'Ducky_sim
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(881, 515)
        Me.Controls.Add(Me.Lbl_Current_Filename)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.TxtB_source)
        Me.Controls.Add(Me.But_End)
        Me.Controls.Add(Me.But_Simulate)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "Ducky_sim"
        Me.Text = "Ducky Simulator"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents But_Simulate As Windows.Forms.Button
    Friend WithEvents But_End As Windows.Forms.Button
    Friend WithEvents TxtB_source As Windows.Forms.TextBox
    Friend WithEvents Timer1 As Windows.Forms.Timer
    Friend WithEvents MenuStrip1 As Windows.Forms.MenuStrip
    Friend WithEvents ToolStripMenuItem1 As Windows.Forms.ToolStripMenuItem
    Friend WithEvents StartSimulationToolStripMenuItem As Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As Windows.Forms.ToolStripMenuItem
    Friend WithEvents PictureBox1 As Windows.Forms.PictureBox
    Friend WithEvents ToolStripSeparator1 As Windows.Forms.ToolStripSeparator
    Friend WithEvents HelpToolStripMenuItem As Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContentToolStripMenuItem As Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As Windows.Forms.ToolStripSeparator
    Friend WithEvents LoadToolStripMenuItem As Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveToolStripMenuItem As Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator3 As Windows.Forms.ToolStripSeparator
    Friend WithEvents OpenFileDialog1 As Windows.Forms.OpenFileDialog
    Friend WithEvents SaveFileDialog1 As Windows.Forms.SaveFileDialog
    Friend WithEvents CompileCodeToolStripMenuItem As Windows.Forms.ToolStripMenuItem
    Friend WithEvents Lbl_Current_Filename As Windows.Forms.Label
    Friend WithEvents FolderBrowserDialog1 As Windows.Forms.FolderBrowserDialog
End Class
