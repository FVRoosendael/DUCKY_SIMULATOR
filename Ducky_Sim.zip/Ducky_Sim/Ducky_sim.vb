﻿' key ref. https://docs.hak5.org/hc/en-us/articles/360010555153-Ducky-Script-the-USB-Rubber-Ducky-language


Imports System.Diagnostics
'Imports System.Runtime.InteropServices
Imports System.Windows.Forms
Imports System.IO




Public Class Ducky_sim

    Private Declare Sub keybd_event Lib "user32" (ByVal bVk As Byte, ByVal bScan As Byte, ByVal dwFlags As Long, ByVal dwExtraInfo As Long)
    Private Const KEYEVENTF_KEYUP = &H2
    Private Const KEYEVENTF_KEYDOWN = &H0

    Private Const VK_STARTKEY = &H5B
    Private Const VK_SUBTRACT = &H6D
    Private Const VK_ADD = &H6B
    Private Const VK_ESCAPE = &H1B

    Private Last_Command = ""
    Private DEF_DELAY = 500

    Private Current_Filename = ""


    Private Sub END_PROGRAM()
        End
    End Sub

    Private Sub But_End_Click(sender As Object, e As EventArgs) Handles But_End.Click
        END_PROGRAM()
    End Sub

    Private Sub Send_Win_plus(input_c As Char)
        ' Press the Windows key
        keybd_event(Keys.LWin, 0, KEYEVENTF_KEYDOWN, 0)
        ' Press and Release the other key
        Select Case input_c
            Case "A", "a"
                keybd_event(Keys.A, 0, KEYEVENTF_KEYDOWN, 0)
                keybd_event(Keys.A, 0, KEYEVENTF_KEYUP, 0)
            Case "B", "b"
                keybd_event(Keys.B, 0, KEYEVENTF_KEYDOWN, 0)
                keybd_event(Keys.B, 0, KEYEVENTF_KEYUP, 0)
            Case "C", "c"
                keybd_event(Keys.C, 0, KEYEVENTF_KEYDOWN, 0)
                keybd_event(Keys.C, 0, KEYEVENTF_KEYUP, 0)
            Case "D", "d"
                keybd_event(Keys.D, 0, KEYEVENTF_KEYDOWN, 0)
                keybd_event(Keys.D, 0, KEYEVENTF_KEYUP, 0)
            Case "E", "e"
                keybd_event(Keys.E, 0, KEYEVENTF_KEYDOWN, 0)
                keybd_event(Keys.E, 0, KEYEVENTF_KEYUP, 0)
            Case "F", "f"
                keybd_event(Keys.F, 0, KEYEVENTF_KEYDOWN, 0)
                keybd_event(Keys.F, 0, KEYEVENTF_KEYUP, 0)
            Case "G", "g"
                keybd_event(Keys.G, 0, KEYEVENTF_KEYDOWN, 0)
                keybd_event(Keys.G, 0, KEYEVENTF_KEYUP, 0)
            Case "H", "h"
                keybd_event(Keys.H, 0, KEYEVENTF_KEYDOWN, 0)
                keybd_event(Keys.H, 0, KEYEVENTF_KEYUP, 0)
            Case "I", "i"
                keybd_event(Keys.I, 0, KEYEVENTF_KEYDOWN, 0)
                keybd_event(Keys.I, 0, KEYEVENTF_KEYUP, 0)
            Case "J", "j"
                keybd_event(Keys.J, 0, KEYEVENTF_KEYDOWN, 0)
                keybd_event(Keys.J, 0, KEYEVENTF_KEYUP, 0)
            Case "K", "k"
                keybd_event(Keys.K, 0, KEYEVENTF_KEYDOWN, 0)
                keybd_event(Keys.K, 0, KEYEVENTF_KEYUP, 0)
            Case "L", "l"
                keybd_event(Keys.L, 0, KEYEVENTF_KEYDOWN, 0)
                keybd_event(Keys.L, 0, KEYEVENTF_KEYUP, 0)
            Case "M", "m"
                keybd_event(Keys.M, 0, KEYEVENTF_KEYDOWN, 0)
                keybd_event(Keys.M, 0, KEYEVENTF_KEYUP, 0)
            Case "N", "n"
                keybd_event(Keys.N, 0, KEYEVENTF_KEYDOWN, 0)
                keybd_event(Keys.N, 0, KEYEVENTF_KEYUP, 0)
            Case "O", "o"
                keybd_event(Keys.O, 0, KEYEVENTF_KEYDOWN, 0)
                keybd_event(Keys.O, 0, KEYEVENTF_KEYUP, 0)
            Case "P", "p"
                keybd_event(Keys.P, 0, KEYEVENTF_KEYDOWN, 0)
                keybd_event(Keys.P, 0, KEYEVENTF_KEYUP, 0)
            Case "Q", "q"
                keybd_event(Keys.Q, 0, KEYEVENTF_KEYDOWN, 0)
                keybd_event(Keys.Q, 0, KEYEVENTF_KEYUP, 0)
            Case "R", "r"
                keybd_event(Keys.R, 0, KEYEVENTF_KEYDOWN, 0)
                keybd_event(Keys.R, 0, KEYEVENTF_KEYUP, 0)
            Case "S", "s"
                keybd_event(Keys.S, 0, KEYEVENTF_KEYDOWN, 0)
                keybd_event(Keys.S, 0, KEYEVENTF_KEYUP, 0)
            Case "T", "t"
                keybd_event(Keys.T, 0, KEYEVENTF_KEYDOWN, 0)
                keybd_event(Keys.T, 0, KEYEVENTF_KEYUP, 0)
            Case "U", "u"
                keybd_event(Keys.U, 0, KEYEVENTF_KEYDOWN, 0)
                keybd_event(Keys.U, 0, KEYEVENTF_KEYUP, 0)
            Case "V", "v"
                keybd_event(Keys.V, 0, KEYEVENTF_KEYDOWN, 0)
                keybd_event(Keys.V, 0, KEYEVENTF_KEYUP, 0)
            Case "W", "w"
                keybd_event(Keys.W, 0, KEYEVENTF_KEYDOWN, 0)
                keybd_event(Keys.W, 0, KEYEVENTF_KEYUP, 0)
            Case "X", "x"
                keybd_event(Keys.X, 0, KEYEVENTF_KEYDOWN, 0)
                keybd_event(Keys.X, 0, KEYEVENTF_KEYUP, 0)
            Case "Y", "y"
                keybd_event(Keys.Y, 0, KEYEVENTF_KEYDOWN, 0)
                keybd_event(Keys.Y, 0, KEYEVENTF_KEYUP, 0)
            Case "Z", "z"
                keybd_event(Keys.Z, 0, KEYEVENTF_KEYDOWN, 0)
                keybd_event(Keys.Z, 0, KEYEVENTF_KEYUP, 0)
            Case "1"
                keybd_event(Keys.D1, 0, KEYEVENTF_KEYDOWN, 0)
                keybd_event(Keys.D1, 0, KEYEVENTF_KEYUP, 0)
            Case "2"
                keybd_event(Keys.D2, 0, KEYEVENTF_KEYDOWN, 0)
                keybd_event(Keys.D2, 0, KEYEVENTF_KEYUP, 0)
            Case "3"
                keybd_event(Keys.D3, 0, KEYEVENTF_KEYDOWN, 0)
                keybd_event(Keys.D3, 0, KEYEVENTF_KEYUP, 0)
            Case "4"
                keybd_event(Keys.D4, 0, KEYEVENTF_KEYDOWN, 0)
                keybd_event(Keys.D4, 0, KEYEVENTF_KEYUP, 0)
            Case "5"
                keybd_event(Keys.D5, 0, KEYEVENTF_KEYDOWN, 0)
                keybd_event(Keys.D5, 0, KEYEVENTF_KEYUP, 0)
            Case "6"
                keybd_event(Keys.D6, 0, KEYEVENTF_KEYDOWN, 0)
                keybd_event(Keys.D6, 0, KEYEVENTF_KEYUP, 0)
            Case "7"
                keybd_event(Keys.D7, 0, KEYEVENTF_KEYDOWN, 0)
                keybd_event(Keys.D7, 0, KEYEVENTF_KEYUP, 0)
            Case "8"
                keybd_event(Keys.D8, 0, KEYEVENTF_KEYDOWN, 0)
                keybd_event(Keys.D8, 0, KEYEVENTF_KEYUP, 0)
            Case "9"
                keybd_event(Keys.D9, 0, KEYEVENTF_KEYDOWN, 0)
                keybd_event(Keys.D9, 0, KEYEVENTF_KEYUP, 0)
            Case "0"
                keybd_event(Keys.D0, 0, KEYEVENTF_KEYDOWN, 0)
                keybd_event(Keys.D0, 0, KEYEVENTF_KEYUP, 0)
            Case Else
                MsgBox("Error In line GUI")
        End Select
        ' Release the lWIN keys
        keybd_event(Keys.LWin, 0, KEYEVENTF_KEYUP, 0)
    End Sub
    Private Sub Send_Apps_key()
        keybd_event(Keys.Apps, 0, KEYEVENTF_KEYDOWN, 0)
        keybd_event(Keys.Apps, 0, KEYEVENTF_KEYUP, 0)
    End Sub
    Private Sub Send_Shift_plus(input_s As String)
        'Unlike CAPSLOCK, cruise control for cool, the SHIFT command can be used when navigating fields to select text, among other functions.
        Select Case input_s
            Case "DELETE"
                System.Windows.Forms.SendKeys.Send("+{DELETE}")
            Case "HOME"
                System.Windows.Forms.SendKeys.Send("+{HOME}")
            Case "INSERT"
                System.Windows.Forms.SendKeys.Send("+{INSERT}")
            Case "PAGEUP"
                System.Windows.Forms.SendKeys.Send("+{PGUP}")
            Case "PAGEDOWN"
                System.Windows.Forms.SendKeys.Send("+{PGDN}")
            Case "WINDOWS"
            Case "GUI"
            Case "UPARROW"
                System.Windows.Forms.SendKeys.Send("+{UP}")
            Case "DOWNARROW"
                System.Windows.Forms.SendKeys.Send("+{DOWN}")
            Case "LEFTARROW"
                System.Windows.Forms.SendKeys.Send("+{LEFT}")
            Case "RIGHTARROW"
                System.Windows.Forms.SendKeys.Send("+{RIGHT}")
            Case "TAB"
                System.Windows.Forms.SendKeys.Send("+{TAB}")
            Case Else
                MsgBox("Error In line SHIFT")
                'single character
                If input_s.Length > 1 Then
                    MsgBox("Error In line SHIFT - only one char after SHIFT command")
                Else
                    Dim output_s = "+" + input_s
                    System.Windows.Forms.SendKeys.Send(output_s)
                End If
        End Select
    End Sub
    Private Sub Send_ALT_plus(input_s As String)
        'Found to the left of the space key on most keyboards, the ALT key is instrumental in many automation operations. ALT is envious of CONTROL
        Select Case input_s
            Case "END"
                System.Windows.Forms.SendKeys.Send("%{END}")
            Case "ESC", "ESCAPE"
                System.Windows.Forms.SendKeys.Send("%{ESC}")
            Case "F1"
                System.Windows.Forms.SendKeys.Send("%{F1}")
            Case "F2"
                System.Windows.Forms.SendKeys.Send("%{F2}")
            Case "F3"
                System.Windows.Forms.SendKeys.Send("%{F3}")
            Case "F4"
                System.Windows.Forms.SendKeys.Send("%{F4}")
            Case "F5"
                System.Windows.Forms.SendKeys.Send("%{F5}")
            Case "F6"
                System.Windows.Forms.SendKeys.Send("%{F6}")
            Case "F7"
                System.Windows.Forms.SendKeys.Send("%{F7}")
            Case "F8"
                System.Windows.Forms.SendKeys.Send("%{F8}")
            Case "F9"
                System.Windows.Forms.SendKeys.Send("%{F9}")
            Case "F10"
                System.Windows.Forms.SendKeys.Send("%{F10}")
            Case "F11"
                System.Windows.Forms.SendKeys.Send("%{F11}")
            Case "F12"
                System.Windows.Forms.SendKeys.Send("%{F12}")
            Case "SPACE"
                keybd_event(Keys.Menu, 0, KEYEVENTF_KEYDOWN, 0)
                keybd_event(Keys.Space, 0, KEYEVENTF_KEYDOWN, 0)
                keybd_event(Keys.Space, 0, KEYEVENTF_KEYUP, 0)
                keybd_event(Keys.Menu, 0, KEYEVENTF_KEYUP, 0)
            Case "TAB"
                System.Windows.Forms.SendKeys.Send("%{TAB}")
            Case Else
                'single character
                If input_s.Length > 1 Then
                    MsgBox("Error In line ALT - only one char after ALT command")
                Else
                    Dim output_s = "%" + input_s
                    System.Windows.Forms.SendKeys.Send(output_s)
                End If
                'Else
                'MsgBox("Error In line ALT")
        End Select
    End Sub
    Private Sub Send_CTRL_plus(input_s As String)
        'The king of key-combos, CONTROL is all mighty.
        Select Case input_s
            Case "BREAK", "PAUSE"
                System.Windows.Forms.SendKeys.Send("^{END}")
            Case "F1"
                System.Windows.Forms.SendKeys.Send("^{F1}")
            Case "F2"
                System.Windows.Forms.SendKeys.Send("^{F2}")
            Case "F3"
                System.Windows.Forms.SendKeys.Send("^{F3}")
            Case "F4"
                System.Windows.Forms.SendKeys.Send("^{F4}")
            Case "F5"
                System.Windows.Forms.SendKeys.Send("^{F5}")
            Case "F6"
                System.Windows.Forms.SendKeys.Send("^{F6}")
            Case "F7"
                System.Windows.Forms.SendKeys.Send("^{F7}")
            Case "F8"
                System.Windows.Forms.SendKeys.Send("^{F8}")
            Case "F9"
                System.Windows.Forms.SendKeys.Send("^{F9}")
            Case "F10"
                System.Windows.Forms.SendKeys.Send("^{F10}")
            Case "F11"
                System.Windows.Forms.SendKeys.Send("^{F11}")
            Case "F12"
                System.Windows.Forms.SendKeys.Send("^{F12}")
            Case "ESC", "ESCAPE"
                System.Windows.Forms.SendKeys.Send("^{ESC}")
            Case "SPACE"
                keybd_event(Keys.Menu, 0, KEYEVENTF_KEYDOWN, 0)
                keybd_event(Keys.Space, 0, KEYEVENTF_KEYDOWN, 0)
                keybd_event(Keys.Space, 0, KEYEVENTF_KEYUP, 0)
                keybd_event(Keys.Menu, 0, KEYEVENTF_KEYUP, 0)
            Case "TAB"
                System.Windows.Forms.SendKeys.Send("^{TAB}")
            Case Else
                'single character
                If input_s.Length > 1 Then
                    MsgBox("Error In line CTRL - only one char after CTRL command")
                Else
                    Dim output_s = "^" + input_s
                    System.Windows.Forms.SendKeys.Send(output_s)
                End If
                'Else
                'MsgBox("Error In line CTRL")
        End Select
    End Sub

    Private Sub Run_Line_of_code(input_line As String)
        Dim LINE_firstword As String = input_line.Split(" ")(0)
        Dim LINE_Resto_of_Line As String = input_line.Substring(input_line.IndexOf(" ") + 1)
        Dim LINE_NumOfWords = input_line.Split(" ").Length
        Select Case LINE_firstword
            Case "REM", ""
                ' do nothing
            Case "GUI"
                If LINE_Resto_of_Line.Length > 1 Then
                    MsgBox("Error In line GUI - only one char after GUI command")
                Else
                    Send_Win_plus(LINE_Resto_of_Line)
                End If
            Case "DELAY"
                'DELAY creates a momentary pause in the ducky script. 
                'DELAY time is specified in milliseconds from 1 to 10000 = max 10 sec
                If LINE_NumOfWords > 1 Then
                    ' MsgBox(Resto_of_Line)
                    Dim numericCheck = IsNumeric(LINE_Resto_of_Line)
                    If numericCheck Then
                        Threading.Thread.Sleep(LINE_Resto_of_Line)
                    Else
                        MsgBox("error in line DELAY")
                    End If
                End If
            Case "STRING"
                ' STRING processes the text following taking special care to auto-shift. STRING can accept a single or multiple characters.
                ' STRING | a…z A…Z 0…9 !…) `~+=_-“‘;:<,>.?[{]}/|!@#$%^&*()
                ' special caracters like + needs to be {+}
                LINE_Resto_of_Line = LINE_Resto_of_Line.Replace("+", "{+}")
                LINE_Resto_of_Line = LINE_Resto_of_Line.Replace("(", "{(}")
                LINE_Resto_of_Line = LINE_Resto_of_Line.Replace(")", "{)}")
                LINE_Resto_of_Line = LINE_Resto_of_Line.Replace("[", "{[}")
                LINE_Resto_of_Line = LINE_Resto_of_Line.Replace("]", "{]}")
                LINE_Resto_of_Line = LINE_Resto_of_Line.Replace("~", "{~}")
                LINE_Resto_of_Line = LINE_Resto_of_Line.Replace("^", "{^}")
                LINE_Resto_of_Line = LINE_Resto_of_Line.Replace("%", "{%}")
                System.Windows.Forms.SendKeys.Send(LINE_Resto_of_Line)
            Case "MENU", "APP"
                Send_Apps_key()
            Case "SHIFT"
                LINE_Resto_of_Line = LINE_Resto_of_Line.Replace("+", "{+}")
                LINE_Resto_of_Line = LINE_Resto_of_Line.Replace("(", "{(}")
                LINE_Resto_of_Line = LINE_Resto_of_Line.Replace(")", "{)}")
                LINE_Resto_of_Line = LINE_Resto_of_Line.Replace("[", "{[}")
                LINE_Resto_of_Line = LINE_Resto_of_Line.Replace("]", "{]}")
                LINE_Resto_of_Line = LINE_Resto_of_Line.Replace("~", "{~}")
                LINE_Resto_of_Line = LINE_Resto_of_Line.Replace("^", "{^}")
                LINE_Resto_of_Line = LINE_Resto_of_Line.Replace("%", "{%}")
                Send_Shift_plus(LINE_Resto_of_Line)
            Case "ALT"
                LINE_Resto_of_Line = LINE_Resto_of_Line.Replace("+", "{+}")
                LINE_Resto_of_Line = LINE_Resto_of_Line.Replace("(", "{(}")
                LINE_Resto_of_Line = LINE_Resto_of_Line.Replace(")", "{)}")
                LINE_Resto_of_Line = LINE_Resto_of_Line.Replace("[", "{[}")
                LINE_Resto_of_Line = LINE_Resto_of_Line.Replace("]", "{]}")
                LINE_Resto_of_Line = LINE_Resto_of_Line.Replace("~", "{~}")
                LINE_Resto_of_Line = LINE_Resto_of_Line.Replace("^", "{^}")
                LINE_Resto_of_Line = LINE_Resto_of_Line.Replace("%", "{%}")
                Send_ALT_plus(LINE_Resto_of_Line)
            Case "CONTROL", "CTRL"
                LINE_Resto_of_Line = LINE_Resto_of_Line.Replace("+", "{+}")
                LINE_Resto_of_Line = LINE_Resto_of_Line.Replace("(", "{(}")
                LINE_Resto_of_Line = LINE_Resto_of_Line.Replace(")", "{)}")
                LINE_Resto_of_Line = LINE_Resto_of_Line.Replace("[", "{[}")
                LINE_Resto_of_Line = LINE_Resto_of_Line.Replace("]", "{]}")
                LINE_Resto_of_Line = LINE_Resto_of_Line.Replace("~", "{~}")
                LINE_Resto_of_Line = LINE_Resto_of_Line.Replace("^", "{^}")
                LINE_Resto_of_Line = LINE_Resto_of_Line.Replace("%", "{%}")
                Send_CTRL_plus(LINE_Resto_of_Line)
            Case "ENTER"
                System.Windows.Forms.SendKeys.Send("{Enter}")
            Case "DOWNARROW", "DOWN"
                System.Windows.Forms.SendKeys.Send("{DOWN}")
            Case "LEFTARROW", "LEFT"
                System.Windows.Forms.SendKeys.Send("{LEFT}")
            Case "RIGHTARROW", "RIGHT"
                System.Windows.Forms.SendKeys.Send("{RIGHT}")
            Case "UPARROW", "UP"
                System.Windows.Forms.SendKeys.Send("{UP}")
            Case "BREAK", "PAUSE"
                System.Windows.Forms.SendKeys.Send("{BREAK}")
            Case "CAPSLOCK"
                System.Windows.Forms.SendKeys.Send("{CAPSLOCK}")
            Case "DELETE"
                System.Windows.Forms.SendKeys.Send("{DEL}")
            Case "END"
                System.Windows.Forms.SendKeys.Send("{END}")
            Case "ESC", "ESCAPE"
                System.Windows.Forms.SendKeys.Send("{ESC}")
            Case "HOME"
                System.Windows.Forms.SendKeys.Send("{HOME}")
            Case "INSERT"
                System.Windows.Forms.SendKeys.Send("{INSERT}")
            Case "NUMLOCK"
                System.Windows.Forms.SendKeys.Send("{NUMLOCK}")
            Case "PAGEUP"
                System.Windows.Forms.SendKeys.Send("{PGUP}")
            Case "PAGEDOWN"
                System.Windows.Forms.SendKeys.Send("{PGDN}")
            Case "PRINTSCREEN"
                System.Windows.Forms.SendKeys.Send("{PRTSC}")
            Case "SCROLLOCK"
                System.Windows.Forms.SendKeys.Send("{SCROLLLOCK}")
            Case "SPACE"
                keybd_event(Keys.Space, 0, KEYEVENTF_KEYDOWN, 0)
                keybd_event(Keys.Space, 0, KEYEVENTF_KEYUP, 0)
            Case "TAB"
                System.Windows.Forms.SendKeys.Send("{TAB}")
            Case "ALT-SHIFT"
                'System.Windows.Forms.SendKeys.Send("%+{DEL}")
            Case "CTRL-ALT"
                'System.Windows.Forms.SendKeys.Send("^%{DEL}")
            Case "CTRL-SHIFT"
                'System.Windows.Forms.SendKeys.Send("^+{DEL}")
            Case "COMMAND" 'only or OSX users
            Case "REPEAT"
                If LINE_NumOfWords > 1 Then
                    ' MsgBox(Resto_of_Line)
                    Dim numericCheck = IsNumeric(LINE_Resto_of_Line)
                    If numericCheck Then
                        'MsgBox(LINE_Resto_of_Line)
                        'MsgBox(Last_Command)
                        Dim R_Count = 0
                        For R_Count = 1 To LINE_Resto_of_Line
                            'MsgBox(Last_Command)
                            Run_Line_of_code(Last_Command)
                        Next
                    Else
                        MsgBox("error in line REPEAT")
                    End If
                End If
            Case "DEFAULT_DELAY", "DEFAULTDELAY"
                'DEFAULT_DELAY or DEFAULTDELAY is used to define how long (in milliseconds * 10) to wait between each subsequent command.
                If LINE_NumOfWords > 1 Then
                    ' MsgBox(Resto_of_Line)
                    Dim numericCheck = IsNumeric(LINE_Resto_of_Line)
                    If numericCheck Then
                        DEF_DELAY = LINE_Resto_of_Line
                    Else
                        MsgBox("error in line DEFAULT_DELAY")
                    End If
                End If
            Case "F1"
                SendKeys.Send("{F1}")
            Case "F2"
                System.Windows.Forms.SendKeys.Send("{F2}")
            Case "F3"
                System.Windows.Forms.SendKeys.Send("{F3}")
            Case "F4"
                System.Windows.Forms.SendKeys.Send("{F4}")
            Case "F5"
                System.Windows.Forms.SendKeys.Send("{F5}")
            Case "F6"
                System.Windows.Forms.SendKeys.Send("{F6}")
            Case "F7"
                System.Windows.Forms.SendKeys.Send("{F7}")
            Case "F8"
                System.Windows.Forms.SendKeys.Send("{F8}")
            Case "F9"
                System.Windows.Forms.SendKeys.Send("{F9}")
            Case "F10"
                System.Windows.Forms.SendKeys.Send("{F10}")
            Case "F11"
                System.Windows.Forms.SendKeys.Send("{F11}")
            Case "F12"
                System.Windows.Forms.SendKeys.Send("{F12}")
        End Select
        'MsgBox("line processed")
    End Sub

    Private Sub START_PROGRAM()
        ' read line by line
        ' translate ref. https://docs.hak5.org/hc/en-us/articles/360010555153-Ducky-Script-the-USB-Rubber-Ducky-language
        For Each strLine As String In TxtB_source.Text.Split(vbNewLine)
            'clean up special characters in lines of input
            strLine = strLine.Replace(vbNewLine, [String].Empty)
            strLine = strLine.Replace(vbLf, [String].Empty)
            strLine = strLine.Replace(vbCr, [String].Empty)
            strLine = strLine.Replace(vbTab, [String].Empty)
            Run_Line_of_code(strLine)
            Threading.Thread.Sleep(DEF_DELAY)
            'make this line the last command (used by REPEAT)
            Last_Command = strLine
        Next
        MsgBox("Simulation Completed")
    End Sub

    Private Sub But_Simulate_Click(sender As Object, e As EventArgs) Handles But_Simulate.Click
        START_PROGRAM()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        END_PROGRAM()
    End Sub

    Private Sub StartSimulationToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles StartSimulationToolStripMenuItem.Click
        START_PROGRAM()
    End Sub

    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        Dim box = New Form_About()
        box.Show()
    End Sub

    Private Sub ContentToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ContentToolStripMenuItem.Click
        Dim webAddress As String = "https://www.afavor-it.be/en/"
        Process.Start(webAddress)
    End Sub

    Private Sub Ducky_sim_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Lbl_Current_Filename.Text = "Current FileName:"
    End Sub

    Private Sub LoadToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LoadToolStripMenuItem.Click
        ' Call ShowDialog.
        Dim result As DialogResult = OpenFileDialog1.ShowDialog()
        ' Test result.
        If result = Windows.Forms.DialogResult.OK Then
            ' Get the file name.
            Dim path As String = OpenFileDialog1.FileName
            Current_Filename = path
            Lbl_Current_Filename.Text = "Current FileName: " + Current_Filename
            Try
                ' Read in text.
                Dim text As String = File.ReadAllText(path)
                ' For debugging.
                TxtB_source.Text = text
            Catch ex As Exception
                ' Report an error.
                TxtB_source.Text = "Error loading file"
            End Try
        End If
    End Sub

    Private Sub SaveToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SaveToolStripMenuItem.Click
        ' Call ShowDialog.
        'Dim result As DialogResult = SaveFileDialog1.ShowDialog()
        SaveFileDialog1.Filter = "TXT Files (*.txt*)|*.txt"
        SaveFileDialog1.InitialDirectory = Current_Filename
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK _
         Then
            File.WriteAllText(SaveFileDialog1.FileName, TxtB_source.Text)
            Current_Filename = SaveFileDialog1.FileName
            Lbl_Current_Filename.Text = Current_Filename
            Lbl_Current_Filename.Text = "Current FileName: " + Current_Filename
        End If
    End Sub

    Private Sub CompileCodeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CompileCodeToolStripMenuItem.Click

        If Current_Filename = "" Then
            MsgBox("Please save file first")
        Else
            Dim Form_compile = New Form_Compile()
            Form_compile.Show()

            'Form_compile.Lbl_Current_Filename.Text = Lbl_Current_Filename.Text
            Form_compile.TxtB_FileName.Text = Me.Current_Filename
            'Dim Cur_Folder = ""
            'Cur_Folder = CurDir() & "\"
            'Dim jar_exists = 0
            'Dim java_exists = 0
            'Dim jar_location = Cur_Folder & "duckencode.jar"
            'Dim java_location = Cur_Folder & "jre\bin\java.exe"
            'Check if duckencode.jar exists
            'If File.Exists(jar_location) Then
            ' jar_exists = 1
            'Else
            '    FolderBrowserDialog1.SelectedPath = FolderBrowserDialog1.ShowDialog()
            'jar_exists = 0
            'End If
            'Check if java.exe exists
            'If File.Exists(java_location) Then
            ' java_exists = 1
            ' Else
            ' java_exists = 0
            'End If
            'If jar_exists And java_exists Then
            'MsgBox("inject.bin file created")
            'Else
            'MsgBox("requirements NOT OK")
            'End If


            'run command
            'Dim Cur_command = ""
            ' executes "java.exe -jar c:\temp\duckencode.jar -i c:\temp\script.txt -o c:\temp\inject.bin"
            'Dim OpenCMD
            'OpenCMD = CreateObject("wscript.shell")

            'Cur_command = Chr(34) & "c:\Program Files\Java\jdk1.8.0_131\bin\java.exe" & Chr(34) & " -jar " & Cur_Folder & "duckencode.jar -i " & Cur_Folder & Cur_tempFile & " -o " & Cur_Folder & "inject.bin"
            'Cur_command = Chr(34) & "jre\bin\java.exe" & Chr(34) & " -jar " & Cur_Folder & "duckencode.jar -i " & Current_Filename & " -o " & Cur_Folder & "inject.bin"
            'MsgBox(Cur_command)
            'OpenCMD.run(Cur_command)



        End If

    End Sub


End Class


