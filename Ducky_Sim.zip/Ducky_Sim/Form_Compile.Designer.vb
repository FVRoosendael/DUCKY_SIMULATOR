﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form_Compile
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Lbl_Current_Filename = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Bt_Compile = New System.Windows.Forms.Button()
        Me.Bt_Cancel = New System.Windows.Forms.Button()
        Me.TxtB_jar = New System.Windows.Forms.TextBox()
        Me.TxtB_java = New System.Windows.Forms.TextBox()
        Me.Bt_select_jar = New System.Windows.Forms.Button()
        Me.Bt_select_java = New System.Windows.Forms.Button()
        Me.TxtB_FileName = New System.Windows.Forms.TextBox()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.SuspendLayout()
        '
        'Lbl_Current_Filename
        '
        Me.Lbl_Current_Filename.AutoSize = True
        Me.Lbl_Current_Filename.Location = New System.Drawing.Point(14, 31)
        Me.Lbl_Current_Filename.Name = "Lbl_Current_Filename"
        Me.Lbl_Current_Filename.Size = New System.Drawing.Size(117, 16)
        Me.Lbl_Current_Filename.TabIndex = 8
        Me.Lbl_Current_Filename.Text = "Current FileName: "
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(7, 66)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(259, 29)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "System requirements"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(15, 114)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(157, 16)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = "Location: duckencode.jar"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(15, 147)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(116, 16)
        Me.Label3.TabIndex = 11
        Me.Label3.Text = "Location Java.exe"
        '
        'Bt_Compile
        '
        Me.Bt_Compile.Location = New System.Drawing.Point(12, 185)
        Me.Bt_Compile.Name = "Bt_Compile"
        Me.Bt_Compile.Size = New System.Drawing.Size(776, 55)
        Me.Bt_Compile.TabIndex = 12
        Me.Bt_Compile.Text = "Generate ""inject.bin"" file for Rubber Ducky"
        Me.Bt_Compile.UseVisualStyleBackColor = True
        '
        'Bt_Cancel
        '
        Me.Bt_Cancel.Location = New System.Drawing.Point(12, 246)
        Me.Bt_Cancel.Name = "Bt_Cancel"
        Me.Bt_Cancel.Size = New System.Drawing.Size(776, 55)
        Me.Bt_Cancel.TabIndex = 13
        Me.Bt_Cancel.Text = "Cancel"
        Me.Bt_Cancel.UseVisualStyleBackColor = True
        '
        'TxtB_jar
        '
        Me.TxtB_jar.Location = New System.Drawing.Point(205, 114)
        Me.TxtB_jar.Name = "TxtB_jar"
        Me.TxtB_jar.Size = New System.Drawing.Size(456, 22)
        Me.TxtB_jar.TabIndex = 14
        '
        'TxtB_java
        '
        Me.TxtB_java.Location = New System.Drawing.Point(205, 147)
        Me.TxtB_java.Name = "TxtB_java"
        Me.TxtB_java.Size = New System.Drawing.Size(456, 22)
        Me.TxtB_java.TabIndex = 15
        '
        'Bt_select_jar
        '
        Me.Bt_select_jar.Location = New System.Drawing.Point(668, 114)
        Me.Bt_select_jar.Name = "Bt_select_jar"
        Me.Bt_select_jar.Size = New System.Drawing.Size(120, 22)
        Me.Bt_select_jar.TabIndex = 16
        Me.Bt_select_jar.Text = "Select"
        Me.Bt_select_jar.UseVisualStyleBackColor = True
        '
        'Bt_select_java
        '
        Me.Bt_select_java.Location = New System.Drawing.Point(668, 147)
        Me.Bt_select_java.Name = "Bt_select_java"
        Me.Bt_select_java.Size = New System.Drawing.Size(120, 23)
        Me.Bt_select_java.TabIndex = 17
        Me.Bt_select_java.Text = "Select"
        Me.Bt_select_java.UseVisualStyleBackColor = True
        '
        'TxtB_FileName
        '
        Me.TxtB_FileName.Enabled = False
        Me.TxtB_FileName.Location = New System.Drawing.Point(205, 28)
        Me.TxtB_FileName.Name = "TxtB_FileName"
        Me.TxtB_FileName.Size = New System.Drawing.Size(456, 22)
        Me.TxtB_FileName.TabIndex = 18
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'Form_Compile
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 317)
        Me.Controls.Add(Me.TxtB_FileName)
        Me.Controls.Add(Me.Bt_select_java)
        Me.Controls.Add(Me.Bt_select_jar)
        Me.Controls.Add(Me.TxtB_java)
        Me.Controls.Add(Me.TxtB_jar)
        Me.Controls.Add(Me.Bt_Cancel)
        Me.Controls.Add(Me.Bt_Compile)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Lbl_Current_Filename)
        Me.Name = "Form_Compile"
        Me.Text = "Compile Ducky Script"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Lbl_Current_Filename As Windows.Forms.Label
    Friend WithEvents Label1 As Windows.Forms.Label
    Friend WithEvents Label2 As Windows.Forms.Label
    Friend WithEvents Label3 As Windows.Forms.Label
    Friend WithEvents Bt_Compile As Windows.Forms.Button
    Friend WithEvents Bt_Cancel As Windows.Forms.Button

    Private Sub Bt_Cancel_Click(sender As Object, e As EventArgs) Handles Bt_Cancel.Click
        Me.Close()
    End Sub

    Friend WithEvents TxtB_jar As Windows.Forms.TextBox
    Friend WithEvents TxtB_java As Windows.Forms.TextBox
    Friend WithEvents Bt_select_jar As Windows.Forms.Button
    Friend WithEvents Bt_select_java As Windows.Forms.Button
    Friend WithEvents TxtB_FileName As Windows.Forms.TextBox

    Private Sub Bt_select_jar_Click(sender As Object, e As EventArgs) Handles Bt_select_jar.Click
        ' Call ShowDialog.
        'Dim result As DialogResult = OpenFileDialog1.ShowDialog()
        OpenFileDialog1.Filter = "Jar Files|*.jar"
        OpenFileDialog1.FileName = ""
        Dim result = OpenFileDialog1.ShowDialog()
        ' Test result.
        If result = Windows.Forms.DialogResult.OK Then
            ' Get the file name.
            TxtB_jar.Text = OpenFileDialog1.FileName
        End If
    End Sub

    Friend WithEvents OpenFileDialog1 As Windows.Forms.OpenFileDialog

    Private Sub Bt_select_java_Click(sender As Object, e As EventArgs) Handles Bt_select_java.Click
        OpenFileDialog1.Filter = "exe Files|*.exe"
        OpenFileDialog1.FileName = "java.exe"
        Dim result = OpenFileDialog1.ShowDialog()
        ' Test result.
        If result = Windows.Forms.DialogResult.OK Then
            ' Get the file name.
            TxtB_java.Text = OpenFileDialog1.FileName
        End If
    End Sub

    Private Sub Bt_Compile_Click(sender As Object, e As EventArgs) Handles Bt_Compile.Click
        'check requirements
        If TxtB_jar.Text IsNot "" And TxtB_java.Text IsNot "" Then
            'define location inject.bin
            SaveFileDialog1.FileName = "inject.bin"
            If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
                'run command
                ' executes "java.exe -jar c:\temp\duckencode.jar -i c:\temp\script.txt -o c:\temp\inject.bin"
                Dim Cur_command = ""
                Dim OpenCMD
                OpenCMD = CreateObject("wscript.shell")
                Cur_command = Chr(34) & TxtB_java.Text & Chr(34) & " -jar " & Chr(34) & TxtB_jar.Text & Chr(34) & " -i " & Chr(34) & TxtB_FileName.Text & Chr(34) & " -o " & Chr(34) & SaveFileDialog1.FileName & Chr(34)
                MsgBox(Cur_command)
                OpenCMD.run(Cur_command)
                'close form
                Me.Close()
            End If
        Else
            MsgBox("PLease fill in all Requirements")
        End If

        'run command
        'Dim Cur_command = ""
        ' executes "java.exe -jar c:\temp\duckencode.jar -i c:\temp\script.txt -o c:\temp\inject.bin"
        'Dim OpenCMD
        'OpenCMD = CreateObject("wscript.shell")

        'Cur_command = Chr(34) & "c:\Program Files\Java\jdk1.8.0_131\bin\java.exe" & Chr(34) & " -jar " & Cur_Folder & "duckencode.jar -i " & Cur_Folder & Cur_tempFile & " -o " & Cur_Folder & "inject.bin"
        'Cur_command = Chr(34) & "jre\bin\java.exe" & Chr(34) & " -jar " & Cur_Folder & "duckencode.jar -i " & Current_Filename & " -o " & Cur_Folder & "inject.bin"
        'MsgBox(Cur_command)
        'OpenCMD.run(Cur_command)
    End Sub

    Friend WithEvents SaveFileDialog1 As Windows.Forms.SaveFileDialog
End Class
